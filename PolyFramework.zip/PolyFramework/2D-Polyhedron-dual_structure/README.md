2D Polyhedron dual Structure 
======================
